/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbs_grp_18sw15.pkg22.pkg24.pkg26;

import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Ibrahim
 */
public class SrchClass {
    
    
    public static void searchDataFromTable(JTable table,String keyword){
        TableRowSorter tableRowSorter = new TableRowSorter(table.getModel());
        table.setRowSorter(tableRowSorter);
        tableRowSorter.setRowFilter(RowFilter.regexFilter("(?i)"+keyword));
    }
}
    

