/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbs_grp_18sw15.pkg22.pkg24.pkg26;

import Connection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;




/**
 *
 * @author Ibrahim
 */
public class DoctorInsert extends javax.swing.JFrame {
    
Connection con = DBConnection.makeConnection();
    DefaultTableModel model;
    

    /**
     * Creates new form HeadCrud
     */
    public DoctorInsert() {
        initComponents();
         model = (DefaultTableModel) doctorTable.getModel();
         showData();
    }
    
    public void showData(){
    model.setRowCount(0);
        try {
            PreparedStatement pst = con.prepareStatement("Select * from doctor ");
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Object[] object = {rs.getInt("Doctor_ID"), rs.getString("Doctor_Name"), rs.getString("Doctor_Age"), rs.getString("Doctor_Contact"), rs.getString("Doctor_Salary"),rs.getString("Doctor_Email"),rs.getString("Doctor_Password")};
                model.addRow(object);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    
    }

    
    public void clearData(){
        
        docName.setText(null);
        docAge.setText(null);
        docCont.setText(null);
        docSal.setText(null);
        docEmail.setText(null);
        docPass.setText(null);
    
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        docName = new javax.swing.JTextField();
        docAge = new javax.swing.JTextField();
        docCont = new javax.swing.JTextField();
        docSal = new javax.swing.JTextField();
        docEmail = new javax.swing.JTextField();
        docPass = new javax.swing.JPasswordField();
        addBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        doctorTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("NAME");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, -1, -1));

        jLabel2.setText("AGE");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, -1, -1));

        jLabel3.setText("CONTACT");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, -1, -1));

        jLabel4.setText("SALARY");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, -1, -1));

        jLabel5.setText("DOCTOR EMAIL");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, -1, -1));

        jLabel6.setText("DOCTOR PASSWORD");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, -1, -1));
        jPanel1.add(docName, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 200, -1));
        jPanel1.add(docAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 200, -1));
        jPanel1.add(docCont, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 220, 200, -1));
        jPanel1.add(docSal, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 280, 200, -1));
        jPanel1.add(docEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 340, 200, -1));
        jPanel1.add(docPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 390, 200, -1));

        addBtn.setText("ADD");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });
        jPanel1.add(addBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 490, -1, -1));

        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });
        jPanel1.add(updateBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 490, -1, -1));

        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        jPanel1.add(deleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 490, -1, -1));

        doctorTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "DocID", "Name", "Age", "Contact", "Salary", "Email", "Password"
            }
        ));
        doctorTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                doctorTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(doctorTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 50, 510, 440));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 549, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        if (docName.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "Enter Doctor Name");
        } 
    else if (doctorTable.getSelectedRow() < 0) {
    
    {
            String Doctor_Name = docName.getText();
            String Doctor_Age= docAge.getText();
            String Doctor_Contact = docCont.getText();
             String Doctor_Salary= docSal.getText();
              String Doctor_Email= docEmail.getText();
              String Doctor_Password= docPass.getText();
            
            
            

            try {
                PreparedStatement pst = con.prepareStatement("Insert into doctor (Doctor_Name,Doctor_Age,Doctor_Contact,Doctor_Salary,Doctor_Email,Doctor_Password) values(?,?,?,?,?,?)");
                pst.setString(1, Doctor_Name);
                pst.setString(2, Doctor_Age);
                pst.setString(3, Doctor_Contact);
                pst.setString(4, Doctor_Salary);
                pst.setString(5, Doctor_Email);
                 pst.setString(6, Doctor_Password); 
   
              

                int check = pst.executeUpdate();
                if (check > 0) {
                    JOptionPane.showMessageDialog(this, "Record added");
                } else {
                    JOptionPane.showMessageDialog(this, "Record not added");
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
           showData();
           clearData();
        } 
    } 
   
    
    else {
            JOptionPane.showMessageDialog(this, "Duplicate record not allowed");
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        
         if(docName.getText().equals("") )
       {
           JOptionPane.showMessageDialog(this,"Select Row First");
       } 
        
        else {
            try {
            
            model = (DefaultTableModel)doctorTable.getModel();
             int select=doctorTable.getSelectedRow();
            String set=(doctorTable.getModel().getValueAt(select, 0).toString());
            String restName=docName.getText();
            String restAge=docAge.getText();
            String restContact=docCont.getText();
            String restSalary=docSal.getText();
            String restEmail=docEmail.getText();
            String restPassword=docPass.getText();
            
             
            PreparedStatement pst = con.prepareStatement("Update doctor SET Doctor_Name='"+restName+"' , Doctor_Age='"+restAge+"', Doctor_Contact='"+restContact+"' , Doctor_Salary='"+restSalary+"' , Doctor_Email='"+restEmail+"'  , Doctor_Password='"+restPassword+"' where Doctor_Id="+set);
          
              pst.executeUpdate();
           
   
             JOptionPane.showMessageDialog(this, "Record  updated");
             

        } 
         
         catch (SQLException ex) {
           
        }
       showData();
        clearData();
    }  
        
        
        
        
        
    }//GEN-LAST:event_updateBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        if(docName.getText().equals(""))
       {
           JOptionPane.showMessageDialog(this,"Select Row First");
       } 
          else{
            try {
             
            model= (DefaultTableModel)doctorTable.getModel();
            int select=doctorTable.getSelectedRow();
            String set=(doctorTable.getModel().getValueAt(select, 0).toString());
             PreparedStatement pst = con.prepareStatement("Delete from doctor where Doctor_Id="+set);
      
            int check = pst.executeUpdate();
            if (check > 0) {
                JOptionPane.showMessageDialog(this, "Record deleted");
            } else {
                JOptionPane.showMessageDialog(this, "Record not deleted");
            }

        } catch (SQLException ex) {
        }
        showData();
        clearData();
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void doctorTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_doctorTableMouseClicked
         model = (DefaultTableModel)doctorTable.getModel();
       int select=doctorTable.getSelectedRow();
       
       docName.setText(model.getValueAt(select,1).toString());
       docAge.setText(model.getValueAt(select,2).toString());
        docCont.setText(model.getValueAt(select,3).toString());
         docSal.setText(model.getValueAt(select,4).toString());
         docEmail.setText(model.getValueAt(select,5).toString());
         docPass.setText(model.getValueAt(select,6).toString());
    }//GEN-LAST:event_doctorTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DoctorInsert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DoctorInsert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DoctorInsert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DoctorInsert.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DoctorInsert().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JTextField docAge;
    private javax.swing.JTextField docCont;
    private javax.swing.JTextField docEmail;
    private javax.swing.JTextField docName;
    private javax.swing.JPasswordField docPass;
    private javax.swing.JTextField docSal;
    private javax.swing.JTable doctorTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
